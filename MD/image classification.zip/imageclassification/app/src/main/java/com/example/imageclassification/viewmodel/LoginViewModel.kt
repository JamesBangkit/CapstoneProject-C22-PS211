package com.example.imageclassification.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.imageclassification.model.UserModel
import com.example.imageclassification.model.UserPreference
import kotlinx.coroutines.launch

class LoginViewModel (private val pref: UserPreference) : ViewModel(){

    fun getUser(): LiveData<UserModel> {
        return pref.getUser().asLiveData()
    }

    fun saveName(name: String) {
        viewModelScope.launch {
            pref.saveName(name)
        }
    }

}