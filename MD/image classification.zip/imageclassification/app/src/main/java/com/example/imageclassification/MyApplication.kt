package com.example.imageclassification

import android.app.Application
import android.content.res.Resources
import com.example.imageclassification.database.AcneDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class MyApplication : Application() {
    private val applicationScope = CoroutineScope(SupervisorJob())
    val database by lazy { AcneDatabase.getDatabase(this, applicationScope) }
    val repository by lazy { AcneRepository(database.acneDao()) }
}