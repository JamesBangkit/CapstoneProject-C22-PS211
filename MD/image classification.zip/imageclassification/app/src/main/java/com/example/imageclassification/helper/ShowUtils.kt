package com.example.imageclassification.helper

import androidx.sqlite.db.SimpleSQLiteQuery

object ShowUtils {
    fun getAcne(name: String): SimpleSQLiteQuery {
        val simpleQuery = StringBuilder().append("SELECT * FROM acne WHERE name = \"$name\"")

        return SimpleSQLiteQuery(simpleQuery.toString())
    }
}