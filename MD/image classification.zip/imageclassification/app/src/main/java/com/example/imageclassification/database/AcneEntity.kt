package com.example.imageclassification.database

import androidx.room.*

@Entity
data class Acne(
    @PrimaryKey
    val acneId: Int,
    val name: String,
    val acneDescription: String,
    val recommendation: String,
    val skincare: String,
    val readmore: String
)