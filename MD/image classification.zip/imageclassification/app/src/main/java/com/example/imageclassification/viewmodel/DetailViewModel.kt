package com.example.imageclassification.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.imageclassification.AcneRepository
import com.example.imageclassification.database.Acne

class DetailViewModel(private val acneRepository: AcneRepository) : ViewModel() {
    fun getAllAcne(name: String): LiveData<List<Acne>> = acneRepository.getAllAcne(name)

}

class ViewModelFactory(private val repository: AcneRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DetailViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DetailViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}