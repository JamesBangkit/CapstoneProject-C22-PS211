package com.example.imageclassification.activity

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.imageclassification.R
import com.example.imageclassification.ViewModelFactory
import com.example.imageclassification.databinding.ActivityMainBinding
import com.example.imageclassification.ml.*
import com.example.imageclassification.model.UserPreference
import com.example.imageclassification.utils.rotateBitmap
import com.example.imageclassification.utils.uriToFile
import com.example.imageclassification.viewmodel.MainViewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.snackbar.Snackbar
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.File
import java.math.BigDecimal
import java.nio.ByteBuffer
import java.nio.ByteOrder

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity(), Toolbar.OnMenuItemClickListener {
    private lateinit var mainViewModel: MainViewModel
    private lateinit var googleSignInClient: GoogleSignInClient
    var bitmap: Bitmap? = null
    lateinit var result: String
    private lateinit var binding: ActivityMainBinding
    val imageSize = 224


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this,
                    "Tidak mendapatkan permission.",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupConfiguration()
        playAnimation1()
        playAnimation2()

        val labels =
            application.assets.open("labels.txt").bufferedReader().use { it.readText() }.split("\n")

        binding.fab.setOnClickListener {
            PopupMenu(this, binding.fab).apply {
                menuInflater.inflate(R.menu.add_image_menu, menu)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    setForceShowIcon(true)
                }
                setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item ->
                    when (item.itemId) {
                        R.id.menu1 ->
                            startCamera()
                        R.id.menu2 ->
                            startGallery()
                    }
                    true
                })
            }.show()
        }


        binding.buttonClearImage.setOnClickListener {
            val dialogBuilder = AlertDialog.Builder(this)
            dialogBuilder.setMessage("Do you want to remove image ?")
                .setCancelable(false)
                .setPositiveButton("Remove", DialogInterface.OnClickListener { dialog, id ->
                    clear()
                })
                .setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, id ->
                    dialog.cancel()
                })

            val alert = dialogBuilder.create()
            alert.show()
        }

        binding.tvResult.setOnClickListener {
            if (bitmap != null) {
                val intent = Intent(this@MainActivity, DetailActivity::class.java)
                when (result) {
                    "Blackhead" -> intent.putExtra(DetailActivity.EXTRA_PREDICTION, "Blackhead")
                    "Cystic" -> intent.putExtra(DetailActivity.EXTRA_PREDICTION, "Cystic")
                    "Pustular" -> intent.putExtra(DetailActivity.EXTRA_PREDICTION, "Pustular")
                    "Rosacea" -> intent.putExtra(DetailActivity.EXTRA_PREDICTION, "Rosacea")
                    "Whitehead" -> intent.putExtra(DetailActivity.EXTRA_PREDICTION, "Whitehead")
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please insert image first!", Toast.LENGTH_SHORT).show()
            }
        }

        binding.buttonPrediction.setOnClickListener(View.OnClickListener {
            if (bitmap != null) {
                binding.buttonPrediction.isEnabled = true

                val model = Modelconverted.newInstance(this)
                val inputFeature0 = TensorBuffer.createFixedSize(
                    intArrayOf(1, imageSize, imageSize, 3),
                    DataType.FLOAT32
                )

                var byteBuffer = ByteBuffer.allocateDirect(4 * imageSize * imageSize * 3)
                byteBuffer.order(ByteOrder.nativeOrder())
                val intValues = IntArray(imageSize * imageSize)
                bitmap!!.getPixels(
                    intValues,
                    0,
                    bitmap!!.width,
                    0,
                    0,
                    bitmap!!.width,
                    bitmap!!.height
                )
                var pixel = 0
                for (i in 0 until imageSize) {
                    for (j in 0 until imageSize) {
                        val `val` = intValues[pixel++]
                        byteBuffer.putFloat(((`val` shr 16) and 0xFF) * (1.0F / 1))
                        byteBuffer.putFloat(((`val` shr 8) and 0xFF) * (1.0F / 1))
                        byteBuffer.putFloat((`val` and 0xFF) * (1.0F / 1))
                    }
                }

                inputFeature0.loadBuffer(byteBuffer)

                val outputs = model.process(inputFeature0)
                val outputFeature0 = outputs.outputFeature0AsTensorBuffer
                for (i in outputFeature0.floatArray.indices) {
                    Log.d(
                        "lihatarray",
                        outputFeature0.floatArray[i].toBigDecimal().times(BigDecimal(100))
                            .toString() + "% - " + labels[i]
                    )
                }

                val max = getPrediction(outputFeature0.floatArray)

                Log.d("lihatindex", labels[max])
                result = labels[max].replace("\r", "")

                binding.tvResult.text = result
                binding.tvResult.visibility = View.VISIBLE
                binding.tvResultImage.visibility = View.VISIBLE
                binding.fab.isEnabled = false
                binding.tvInfoResult.visibility = View.VISIBLE
                binding.buttonPrediction.visibility = View.INVISIBLE
                binding.buttonPrediction.isEnabled = false
                binding.please.visibility = View.INVISIBLE
                Snackbar.make(it, "Tap the result to see details.", Snackbar.LENGTH_LONG).show()

                model.close()
            } else {
                binding.buttonPrediction.isEnabled = false
                Toast.makeText(this, "Please insert image first!", Toast.LENGTH_SHORT).show()
            }
        })

        setupViewModel()
        setUpBottomDrawer()
    }


    private fun setupConfiguration() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)
    }


    private fun clear() {
        binding.ivMain.setImageResource(R.drawable.acne)
        bitmap = null
        binding.ivMain.destroyDrawingCache()
        binding.tvResult.visibility = View.INVISIBLE
        binding.tvResultImage.visibility = View.INVISIBLE
        binding.fab.isEnabled = true
        binding.tvInfoResult.visibility = View.INVISIBLE
        binding.buttonPrediction.visibility = View.VISIBLE
        binding.buttonPrediction.isEnabled = false
        binding.please.visibility = View.VISIBLE
    }

    private fun launchShareIntent() {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_TEXT, getString(R.string.share_message))
            type = "text/plain"
        }
        startActivity(Intent.createChooser(sendIntent, resources.getText(R.string.share)))
    }


    private fun startCamera() {
        val intent = Intent(this, CameraActivity::class.java)
        launcherIntentCameraX.launch(intent)
    }

    private val launcherIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == CAMERA_X_RESULT) {
            val myFile = it.data?.getSerializableExtra("picture") as File
            val isBackCamera = it.data?.getBooleanExtra("isBackCamera", true) as Boolean

            val result = rotateBitmap(
                BitmapFactory.decodeFile(myFile.path),
                isBackCamera
            )
            val image = Bitmap.createScaledBitmap(result, imageSize, imageSize, false)
            bitmap = image

            binding.ivMain.setImageBitmap(result)
        }
    }

    private fun setupViewModel() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[MainViewModel::class.java]

        mainViewModel.getUser().observe(this) { user ->

            if (user.stateOnBoarding) {
                startActivity(Intent(this, OnBoardingActivity::class.java))
                finish()
            } else if (GoogleSignIn.getLastSignedInAccount(this) == null && user.user == "") {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            } else if (user.stateTutorial) {
                startActivity(Intent(this, TutorialActivity::class.java))
                finish()
            } else {
                supportActionBar?.title = "Hello, " + user.user
                if (!allPermissionsGranted()) {
                    ActivityCompat.requestPermissions(
                        this,
                        REQUIRED_PERMISSIONS,
                        REQUEST_CODE_PERMISSIONS
                    )
                }
            }
        }
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, getString(R.string.select_image))
        launcherIntentGallery.launch(chooser)
    }

    private var getFile: File? = null

    private val launcherIntentGallery =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                val selectedImg: Uri = it.data?.data as Uri
                val myFile = uriToFile(selectedImg, this)
                val result = BitmapFactory.decodeFile(myFile.path)
                val image = Bitmap.createScaledBitmap(result, imageSize, imageSize, false)
                bitmap = image
                getFile = myFile
                binding.ivMain.setImageURI(selectedImg)
            }
        }

    var handler: Handler = Handler()
    var runnable: Runnable? = null
    var delay = 500
    override fun onStart() {
        super.onStart()
        handler.postDelayed(Runnable {
            handler.postDelayed(runnable!!, delay.toLong())
            checkButtonAvailability()
        }.also { runnable = it }, delay.toLong())
    }

    private fun checkButtonAvailability() {
        if (bitmap != null) {
            Log.d("ceklah", bitmap.toString())
            binding.buttonPrediction.isEnabled = true
            binding.buttonClearImage.isEnabled = true
            binding.please.visibility = View.INVISIBLE
            binding.buttonClearImage.setImageResource(R.drawable.ic_baseline_close_24)
        } else {
            Log.d("ceklah", bitmap.toString())
            binding.buttonPrediction.isEnabled = false
            binding.buttonClearImage.isEnabled = false
            binding.please.visibility = View.VISIBLE
            binding.buttonClearImage.setImageResource(0)
        }
    }

    private lateinit var bottomDrawerBehavior: BottomSheetBehavior<View>
    override fun onBackPressed() {
        if (bottomDrawerBehavior.state != BottomSheetBehavior.STATE_HIDDEN) {
            bottomDrawerBehavior.state = BottomSheetBehavior.STATE_HIDDEN
            return
        }
        super.onBackPressed()
    }

    private fun setUpBottomDrawer() {
        bottomDrawerBehavior = BottomSheetBehavior.from(binding.bottomDrawer)
        bottomDrawerBehavior.state = BottomSheetBehavior.STATE_HIDDEN

        binding.bar.setNavigationOnClickListener {
            bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HALF_EXPANDED)
        }
        binding.bar.setNavigationIcon(R.drawable.ic_drawer_menu_24px)
        binding.bar.setOnMenuItemClickListener(this)

        binding.navigationView.setNavigationItemSelectedListener { item ->
            bottomDrawerBehavior.state = BottomSheetBehavior.STATE_HIDDEN
            onMenuItemClick(item)
        }

        binding.coordinatorLayout.setOnClickListener {
            bottomDrawerBehavior.state = BottomSheetBehavior.STATE_HIDDEN
        }
    }

    override fun onMenuItemClick(item: MenuItem) = when (item.itemId) {
        R.id.menu1 -> {
            Toast.makeText(this, "Still on development", Toast.LENGTH_SHORT).show()
            true
        }
        R.id.menu2 -> {
            launchShareIntent()
            true
        }
        else -> false
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu_atas, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu1 -> {
                startActivity(Intent(this, TutorialActivity::class.java))
                finish()
                true
            }
            R.id.menu2 -> {
                val dialogBuilder = AlertDialog.Builder(this)

                dialogBuilder.setMessage("Do you want to logout ?")
                    .setCancelable(false)
                    .setPositiveButton("Logout", DialogInterface.OnClickListener { dialog, id ->
                        logout()
                    })
                    .setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, id ->
                        dialog.cancel()
                    })

                val alert = dialogBuilder.create()
                alert.show()
                true
            }

            else -> true
        }
    }

    private fun logout() {
        if (GoogleSignIn.getLastSignedInAccount(this) != null) {
            googleSignInClient.signOut().addOnCompleteListener {
                mainViewModel.logout()
                Toast.makeText(this, "Logging Out", Toast.LENGTH_SHORT).show()
            }
        } else {
            mainViewModel.logout()
            Toast.makeText(this, "Logging Out", Toast.LENGTH_SHORT).show()
        }
    }


    fun getPrediction(arr: FloatArray): Int {
        var ind = 0;
        var min = 0.0f;

        for (i in arr.indices) {
            if (arr[i] > min) {
                min = arr[i]
                ind = i;
            }
        }
        return ind
    }

    private fun playAnimation1() {
        val result = ObjectAnimator.ofFloat(binding.tvResult, View.ALPHA, 1f).setDuration(500)
        val image = ObjectAnimator.ofFloat(binding.tvResultImage, View.ALPHA, 1f).setDuration(500)
        val text = ObjectAnimator.ofFloat(binding.tvInfoResult, View.ALPHA, 1f).setDuration(500)

        val together1 = AnimatorSet().apply {
            playTogether(result, image)
        }

        AnimatorSet().apply {
            playSequentially(
                together1,
                text
            )
            start()
        }

        ObjectAnimator.ofFloat(binding.tvResult, View.TRANSLATION_X, -25f, 25f).apply {
            duration = 3000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()
        ObjectAnimator.ofFloat(binding.tvResultImage, View.TRANSLATION_X, -25f, 25f).apply {
            duration = 3000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()
    }

    private fun playAnimation2() {
        val button =
            ObjectAnimator.ofFloat(binding.buttonPrediction, View.TRANSLATION_X, -25f, 25f).apply {
                duration = 3000
                repeatCount = ObjectAnimator.INFINITE
                repeatMode = ObjectAnimator.REVERSE
            }
        AnimatorSet().apply {
            button.start()
        }
    }

    companion object {
        const val CAMERA_X_RESULT = 200
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }
}