package com.example.imageclassification.model

data class UserModel (
    val stateOnBoarding: Boolean,
    val stateTutorial: Boolean,
    val user: String
)
