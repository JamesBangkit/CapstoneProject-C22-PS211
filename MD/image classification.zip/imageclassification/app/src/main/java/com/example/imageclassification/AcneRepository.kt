package com.example.imageclassification

import androidx.lifecycle.LiveData
import com.example.imageclassification.database.Acne
import com.example.imageclassification.database.AcneDao
import com.example.imageclassification.helper.ShowUtils

class AcneRepository(private val acneDao: AcneDao) {
    fun getAllAcne(name: String): LiveData<List<Acne>> {
        val query = ShowUtils.getAcne(name)
        return acneDao.getAllAcne(query)
    }

}