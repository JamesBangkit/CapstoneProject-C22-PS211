package com.example.imageclassification.database

import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.sqlite.db.SimpleSQLiteQuery
import androidx.sqlite.db.SupportSQLiteQuery

@Dao
interface AcneDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAcne(acne: List<Acne>)

    @RawQuery(observedEntities = [Acne::class])
    fun getAllAcne(query: SupportSQLiteQuery): LiveData<List<Acne>>

}

