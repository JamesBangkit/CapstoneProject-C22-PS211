package com.example.imageclassification

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.imageclassification.database.Acne
import com.example.imageclassification.databinding.ItemAcneBinding

class AcneWithReccomendationAdapter :
    ListAdapter<Acne, AcneWithReccomendationAdapter.WordViewHolder>(
        WordsComparator()
    ) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WordViewHolder {
        val binding = ItemAcneBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return WordViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WordViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class WordViewHolder(private val binding: ItemAcneBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: Acne) {
            binding.tvItemAcne.text = data.name
            binding.tvItemDescription.text = data.acneDescription
            binding.tvItemRecommendation.text = data.recommendation
            binding.skincare.text = data.skincare
            binding.readmore.text = data.readmore
        }
    }

    class WordsComparator : DiffUtil.ItemCallback<Acne>() {
        override fun areItemsTheSame(oldItem: Acne, newItem: Acne): Boolean {
            return oldItem === newItem
        }

        override fun areContentsTheSame(oldItem: Acne, newItem: Acne): Boolean {
            return oldItem.name == newItem.name
        }
    }
}