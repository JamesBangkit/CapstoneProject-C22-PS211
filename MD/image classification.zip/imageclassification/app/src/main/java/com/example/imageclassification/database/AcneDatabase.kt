package com.example.imageclassification.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.imageclassification.helper.InitialDataSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Database(entities = [Acne::class], version = 1, exportSchema = false)
abstract class AcneDatabase : RoomDatabase() {

    abstract fun acneDao(): AcneDao

    companion object {
        @Volatile
        private var INSTANCE: AcneDatabase? = null

        @JvmStatic
        fun getDatabase(context: Context, applicationScope: CoroutineScope): AcneDatabase {
            if (INSTANCE == null) {
                synchronized(AcneDatabase::class.java) {
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                            AcneDatabase::class.java, "acne_database")
                        .fallbackToDestructiveMigration()
                        .addCallback(object :Callback(){
                            override fun onCreate(db: SupportSQLiteDatabase) {
                                super.onCreate(db)
                                INSTANCE?.let { database ->
                                    applicationScope.launch {
                                        val acneDao = database.acneDao()
                                        acneDao.insertAcne(InitialDataSource.getAcne())                             }
                                }
                            }
                        })
                        .build()
                }
            }
            return INSTANCE as AcneDatabase
        }

    }
}