package com.example.imageclassification.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.imageclassification.AcneWithReccomendationAdapter
import com.example.imageclassification.MyApplication
import com.example.imageclassification.databinding.ActivityDetailBinding
import com.example.imageclassification.viewmodel.DetailViewModel
import com.example.imageclassification.viewmodel.ViewModelFactory

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private val detailViewModel: DetailViewModel by viewModels {
        ViewModelFactory((application as MyApplication).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvAcne.layoutManager = LinearLayoutManager(this)

        supportActionBar?.title = "Acne Detail"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val prediction = intent.getStringExtra(EXTRA_PREDICTION)

        val adapter = AcneWithReccomendationAdapter()
        binding.rvAcne.adapter = adapter
        if (prediction != null) {
            detailViewModel.getAllAcne(prediction).observe(this@DetailActivity) {
                Log.d(TAG, "getStudentWithCourse: $it")
                adapter.submitList(it)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    companion object {
        const val EXTRA_PREDICTION = "extra_prediction"
        private const val TAG = "DetailActivity"
    }
}