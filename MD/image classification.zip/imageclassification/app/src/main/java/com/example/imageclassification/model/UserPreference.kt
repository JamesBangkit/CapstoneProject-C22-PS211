package com.example.imageclassification.model

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class UserPreference private constructor(private val dataStore: DataStore<Preferences>) {
    fun getUser(): Flow<UserModel> {
        return dataStore.data.map { preferences ->
            UserModel(
                preferences[ONBOARDING_KEY] ?: true,
                preferences[TUTORIAL_KEY] ?: true,
                preferences[USER_KEY] ?:""
            )
        }
    }

    suspend fun saveUser(user: UserModel) {
        dataStore.edit { preferences ->
            preferences[ONBOARDING_KEY] = user.stateOnBoarding
            preferences[TUTORIAL_KEY] = user.stateTutorial
            preferences[USER_KEY] = user.user
        }
    }

    suspend fun saveName(name: String) {
        dataStore.edit { preferences ->
            preferences[USER_KEY] = name
        }
    }

    suspend fun saveOnboarding(state: Boolean) {
        dataStore.edit { preferences ->
            preferences[ONBOARDING_KEY] = state
        }
    }

    suspend fun saveTutorial(state: Boolean) {
        dataStore.edit { preferences ->
            preferences[TUTORIAL_KEY] = state
        }
    }

    suspend fun logout() {
        dataStore.edit { preferences ->
            preferences[ONBOARDING_KEY] = true
            preferences[TUTORIAL_KEY] = true
            preferences[USER_KEY] = ""
        }
    }

    companion object{
        @Volatile
        private var INSTANCE: UserPreference? = null

        private val ONBOARDING_KEY = booleanPreferencesKey("stateOnBoarding")
        private val TUTORIAL_KEY = booleanPreferencesKey("stateTutorial")
        private val USER_KEY = stringPreferencesKey("user")

        fun getInstance(dataStore: DataStore<Preferences>): UserPreference {
            return INSTANCE ?: synchronized(this) {
                val instance = UserPreference(dataStore)
                INSTANCE = instance
                instance
            }
        }
    }
}