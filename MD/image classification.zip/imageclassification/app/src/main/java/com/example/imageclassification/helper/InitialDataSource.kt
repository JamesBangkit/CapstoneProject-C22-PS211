package com.example.imageclassification.helper

import com.example.imageclassification.database.Acne

object InitialDataSource {
    val acneType1 : String = "Blackhead"
    val acneType2 : String = "Cystic"
    val acneType3 : String = "Pustular"
    val acneType4 : String = "Rosacea"
    val acneType5 : String = "Whitehead"

    val acneDesc1: String = """Blackheads are a type of acne (acne vulgaris). They’re open bumps on the skin that fill with excess oil and dead skin. They look as if dirt is in the bump, but an irregular light reflection off the clogged follicle actually causes the dark spots."""
    val acneDesc2: String = """Cystic acne occurs when bacteria, dead skin cells, and sebum (the substance that makes your face feel oily) get trapped beneath the skin’s surface and become infected. This leads to a large, swollen cyst (bump) that can hurt just to touch."""
    val acneDesc3: String = """Pustules are small bumps on the skin that contain fluid or pus. They usually appear as white bumps surrounded by red skin. These bumps look very similar to pimples, but they can grow quite big. Pustules may be a form of acne typically caused by hormonal imbalances or hormonal changes in the body. This is a very common skin condition, particularly among teenagers and young adults."""
    val acneDesc4: String = """The cause of rosacea is unknown, but it could be due to an overactive immune system, heredity, environmental factors or a combination of these. Rosacea is not caused by poor hygiene and it’s not contagious.

Flare-ups might be triggered by: Hot drinks and spicy foods, Red wine and other alcoholic beverages, Temperature extremes, Emotions, Exercise, Drugs that dilate blood vessels, including some blood pressure medications, Some cosmetic, skin or hair care products."""
    val acneDesc5: String = """Whiteheads are a type of acne (acne vulgaris). Oil and dead skin close off hair follicles or sebaceous glands (oil glands) and form a closed bump on your skin (comedo, plural comedones)."""

    val acneRecom1 : String = """• Cleans with salicylic acid
• Gently exfoliate with AHAs and BHAs
• Pick up a skin brush
• Try topical retinoids
• Use a clay/charcoal mask
• Consider a chemical peel
• Make sure you’re using noncomedogenic products
• Don’t sleep in your makeup
• Avoid pore strips and other home extraction methods"""
    val acneRecom2 : String = """• Use warm compresses to soothe inflammation. Make sure to use a clean washcloth and don’t use water that’s too hot.
• Remove makeup every single night before going to bed.
• Use a gentle facial cleanser. You should wash your face at least once per day in the evening before bed with a gentle cleanser.
• Avoid picking at your skin to lessen irritation and prevent infection from spreading.
• Use a mild foaming facial cleanser, lukewarm water and your fingers (not a washcloth or sponge) to wash your face after you wake up, before going to bed and after exercising or sweating.
• Apply oil-free moisturizer if you feel dry.
• Use noncomedogenic (water-based) makeup and facial products."""
    val acneRecom3 : String = """• Keep the skin around the pustules clean and free of oil. They can do this by washing the area with warm water and mild soap twice a day.
• Use Over-the-counter (OTC) creams, ointments, and soaps can help, particularly those that contain salicylic acid, sulfur, peroxide
• It is important to avoid picking at or popping a pustule. Doing this can cause further damage and extend the healing process. 
• Use Clay masks. This natural clays can draw oil and dirt from the skin, reducing the incidence of pimples. 
• Use Essential oils. Diluting and applying essential oils with anti-inflammatory properties, such as tea tree oil or rosemary oil, to the affected areas may reduce the pain and inflammation of pimples.
• Use Aloe vera gel. Aloe vera is a natural substance with antibacterial and anti-inflammatory properties. """
    val acneRecom4 : String = """There isn't a cure for rosacea, but treatments can help you manage the redness, bumps, and other symptoms.

Your doctor may suggest these medicines:
• Brimonidine (Mirvaso), a gel that tightens blood vessels in the skin to get rid of some of your redness.
• Azelaic acid, a gel and foam that clears up bumps, swelling, and redness.
• Metronidazole (Flagyl) and doxycycline, antibiotics that kill bacteria on your skin and bring down redness and swelling.
• Isotretinoin (Amnesteem, Claravis, and others), an acne drug that clears up skin bumps. Don't use it if you're pregnant because it can cause serious birth defects.
• Ivermectin (Soolantra) and oxymetazoline are topicals that are used to treat rosacea.

It can take you a few weeks or months of using one of these medicines for your skin to improve. Your doctor may also recommend some procedures to treat your rosacea, such as:
• Lasers that use intense light to get rid of blood vessels that have gotten bigger
• Dermabrasion, which sands off the top layer of skin
• Electrocautery, an electric current that zaps damaged blood vessels"""
    val acneRecom5 : String = """Whiteheads are considered a mild form of acne. They’re relatively easy to treat.
• A topical retinoid is the first-line treatment for whiteheads. 
• However, topical retinoids take three months to see any effect. They should ideally be used every day (or night).Topical retinoids are used to prevent acne. They shouldn’t be used as a spot treatment on your pimples. Retinoids work by several mechanisms, but, ultimately, they prevent the pore-clogging process.
• Wear sunscreen daily since your skin will be more sensitive to the sun as a result of using a topical retinoid.
• If you have inflammatory acne (red bumps and pustules on your face) your doctor might also prescribe oral or topical antibiotics, which destroy excess skin bacteria and reduce inflammation and redness. The oral antibiotics are used off-label to treat acne.
• Combined oral-contraceptive birth control pills are also used to reduce acne in women. They’re an FDA-approved contraceptive method."""

    val skincare1 : String = """Nonprescription medications can treat blackheads. These may include:
• Salicylic acid: dissolves dead skin cells to prevent your hair follicles from clogging.
• Azelaic acid: Barley, wheat, rye and other various grains naturally contain azelaic acid. It kills microorganisms on your skin and reduces swelling.
• Benzoyl peroxide: It targets surface bacteria, which often aggravates acne.
• Retinoids (vitamin A derivatives): Break up blackheads and whiteheads and help to prevent clogged pores.
If your blackheads don’t go away with nonprescription medications, your healthcare provider may recommend:
• Prescription-strength retinoids
• Oral antibiotics: reduce the bacteria that cause blackheads.
• Microdermabrasion: A dermatologist uses a specialized instrument to “sand” your skin. Removing the top layers of your skin frees the clogs that cause blackheads.
• Chemical peels: use a mild chemical solution to remove layers of skin and reduce blackheads.
• Laser skin resurfacing: Laser skin resurfacing directs short, concentrated pulsating beams of light at your blackheads. The light beams reduce the amount of oil that your sebaceous glands produce."""
    val skincare2 : String = """• Antibiotics: to fight infections and reduce inflammation
• Isotretinoin: to treat severe cases
• Spironolactone: to regulate oil production
• Steroid shots: injected directly into cysts to reduce inflammation and lessen pain
• Azelaic acid or salicylic acid: to kill bacteria and get rid of excess dead skin cells.
• Benzoyl peroxide: to reduce the number of bacteria on the skin.
• Retinoids (adapalene, tretinoin, tazarotene among others), vitamin A derivatives: help slough dead skin cells."""
    val skincare3 : String = """• Salicylic acid : which works as an exfoliant
• Benzoyl peroxide : which kills the bacteria that cause acne
• Retinoids (adapalene, tretinoin, tazarotene among others), vitamin A derivatives: help slough dead skin cells.
• Clindamycin : killing the bacteria that contribute to inflamed and painful pustular acne"""
    val skincare4 : String = """Choosing skin care products with these specific ingredients may help relieve and calm rosacea symptoms:
• Azelaic acid: This naturally occurring acid has antimicrobial and anti-inflammatory properties that make it helpful for calming rosacea flare-ups and treating severe acne
• Niacinamide: This B vitamin may help reduce redness and inflammation while also helping strengthen your skin’s protective barrier and keep it hydrated. 
• Alpha arbutin: This naturally occurring antioxidant is known for brightening skin and it can help even out skin tone and improve discoloration.
• Ceramides:  Wood highly recommends looking for moisturizers with ceramides, fatty acids that can help your skin retain moisture.
• Aloe:  Aloe may have a temporary calming and soothing effect during a flare-up
• Bisabolol: This active ingredient, which comes from the chamomile flower, may help reduce redness and irritation during a flare-up
• Acetyl tetrapeptide-40: This peptide can reduce inflammation and redness while boosting skin barrier function
• Camellia sinensis leaf extract. This extract, which comes from tea leaves, may protect the skin from sun damage while fighting inflammation"""
    val skincare5 : String = """Ingredients that are effective in their treatment include benzoyl peroxide, salicylic acid and alpha-hydroxy acids.Effective natural remedies are facial steaming, and the application of tea tree oil and witch hazel.
"""

    val readmore1 : String = """• https://www.healthline.com/health/beauty-skin-care/how-to-get-rid-of-blackheads#benzoyl-peroxide 
• https://my.clevelandclinic.org/health/diseases/22038-blackheads """
    val readmore2 : String = """• https://www.floridamedicalclinic.com/blog/how-to-get-rid-of-cystic-acne/#:~:text=Causes%20of%20Cystic%20Acne,can%20hurt%20just%20to%20touch.
• https://my.clevelandclinic.org/health/diseases/21737-cystic-acne"""
    val readmore3 : String = """• https://www.healthline.com/health/pustules
• https://www.verywellhealth.com/what-is-acne-pustule-15579
• https://www.medicalnewstoday.com/articles/325342#prevention"""
    val readmore4 : String = """• https://www.healthline.com/health/rosacea/skin-care-for-rosacea#ingredients-to-try 
• https://www.mayoclinic.org/diseases-conditions/rosacea/symptoms-causes/syc-20353815#:~:text=The%20cause%20of%20rosacea%20is,Hot%20drinks%20and%20spicy%20foods 
• https://www.webmd.com/skin-problems-and-treatments/understanding-rosacea-basics"""
    val readmore5 : String = """•   https://dermcollective.com/how-to-get-rid-of-whiteheads/ 
• https://my.clevelandclinic.org/health/diseases/22039-whiteheads 
• https://www.healthline.com/health/whitehead#prevention """

    fun getAcne(): List<Acne> {
        return listOf(
            Acne(1, acneType1, acneDesc1, acneRecom1, skincare1, readmore1),
            Acne(2, acneType2, acneDesc2, acneRecom2, skincare2, readmore2),
            Acne(3, acneType3, acneDesc3, acneRecom3, skincare3, readmore3),
            Acne(4, acneType4, acneDesc4, acneRecom4, skincare4, readmore4),
            Acne(5, acneType5, acneDesc5, acneRecom5, skincare5, readmore5),
        )
    }
}