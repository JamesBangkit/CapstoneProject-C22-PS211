package com.example.imageclassification

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.imageclassification.databinding.ActivityMainBinding
import com.example.imageclassification.ml.MobilenetV110224Quant
import com.example.imageclassification.model.UserPreference
import com.example.imageclassification.utils.createCustomTempFile
import com.example.imageclassification.utils.reduceRotateFileImage
import com.example.imageclassification.utils.rotateBitmap
import com.example.imageclassification.utils.uriToFile
import com.example.imageclassification.viewmodel.MainViewModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.File

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity(), Toolbar.OnMenuItemClickListener {
    private lateinit var mainViewModel: MainViewModel

    var bitmap: Bitmap? = null
    lateinit var result: String
    private lateinit var binding: ActivityMainBinding

//    @RequiresApi(Build.VERSION_CODES.M)
//    public fun checkandGetpermissions(){
//        if(checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED){
//            requestPermissions(arrayOf(android.Manifest.permission.CAMERA), 100)
//        }
//        else{
//            Toast.makeText(this, "Camera permission granted", Toast.LENGTH_SHORT).show()
//        }
//    }

//    override fun onRequestPermissionsResult(
//        requestCode: Int,
//        permissions: Array<out String>,
//        grantResults: IntArray
//    ) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if(requestCode == 100){
//            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
//            {
//                Toast.makeText(this, "Camera permission granted", Toast.LENGTH_SHORT).show()
//            }
//            else{
//                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
//            }
//        }
//    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this,
                    "Tidak mendapatkan permission.",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

//    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "ACREG"
        supportActionBar?.hide()

        // handling permissions


        val labels = application.assets.open("labels.txt").bufferedReader().use { it.readText() }.split("\n")

        binding.fab.setOnClickListener {
            PopupMenu(this, binding.fab).apply {
                menuInflater.inflate(R.menu.add_image_menu, menu)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    setForceShowIcon(true)
                }
                setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item ->
                    when (item.itemId) {
                        R.id.menu1 ->
                            startCamera()
                        R.id.menu2 ->
                            startGallery()
                    }
                    true
                })
            }.show()
        }


        binding.buttonClearImage.setOnClickListener {
           // build alert dialog
            val dialogBuilder = AlertDialog.Builder(this)

            // set message of alert dialog
            dialogBuilder.setMessage("Do you want to remove image ?")
                    // if the dialog is cancelable
                    .setCancelable(false)
                    // positive button text and action
                    .setPositiveButton("Remove", DialogInterface.OnClickListener {
                        dialog, id -> clear()
                    })
                    // negative button text and action
                    .setNegativeButton("Cancel", DialogInterface.OnClickListener {
                        dialog, id -> dialog.cancel()
                    })

            // create dialog box
            val alert = dialogBuilder.create()
            // show alert dialog
            alert.show()
        }

        binding.tvResult.setOnClickListener {
            if(bitmap!=null) {
                val intent = Intent(this@MainActivity, DetailActivity::class.java)
                intent.putExtra(DetailActivity.EXTRA_PREDICTION, result)
                startActivity(intent)
            } else{
                Toast.makeText(this, "Please insert image first!", Toast.LENGTH_SHORT).show()
            }
        }

        binding.buttonPrediction.setOnClickListener(View.OnClickListener {
            if(bitmap!=null){
                binding.buttonPrediction.isEnabled = true
                var resized = Bitmap.createScaledBitmap(bitmap!!, 224, 224, true)
                val model = MobilenetV110224Quant.newInstance(this)

                var tbuffer = TensorImage.fromBitmap(resized)
                var byteBuffer = tbuffer.buffer

// Creates inputs for reference.
                val inputFeature0 = TensorBuffer.createFixedSize(intArrayOf(1, 224, 224, 3), DataType.UINT8)
                inputFeature0.loadBuffer(byteBuffer)

// Runs model inference and gets result.
                val outputs = model.process(inputFeature0)
                val outputFeature0 = outputs.outputFeature0AsTensorBuffer

                val max = getMax(outputFeature0.floatArray)
                result = labels[max]

                binding.tvResult.setText(result)
                binding.tvResult.visibility = View.VISIBLE
//                binding.tvResult.setTextColor(getColor(R.color.purple_200))
                binding.tvInfoResult.visibility = View.VISIBLE

// Releases model resources if no longer used.
                model.close()
            } else{
                binding.buttonPrediction.isEnabled = false
                Toast.makeText(this, "Please insert image first!", Toast.LENGTH_SHORT).show()
            }
        })

        binding.buttonGallery.setOnClickListener(View.OnClickListener {
//            var intent : Intent = Intent(Intent.ACTION_GET_CONTENT)
//            intent.type = "image/*"
//
//            startActivityForResult(intent, 250)
            startGallery()
        })

        binding.buttonCamera.setOnClickListener(View.OnClickListener {
//            var camera : Intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
//            startActivityForResult(camera, 200)
            startCamera()
        })
        setupViewModel()
        setUpBottomDrawer()
    }

    private fun clear(){
        binding.ivMain.setImageResource(R.drawable.acne)
        bitmap=null
        binding.ivMain.destroyDrawingCache()
//            binding.tvResult.setText()
        binding.tvResult.visibility = View.INVISIBLE
        binding.tvInfoResult.visibility = View.INVISIBLE
    }

    private fun launchShareIntent() {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_TEXT, getString(R.string.share_cyanea_message))
            type = "text/plain"
        }
        startActivity(Intent.createChooser(sendIntent, resources.getText(R.string.share)))
    }


    private fun startCamera() {
        val intent = Intent(this, CameraActivity::class.java)
        launcherIntentCameraX.launch(intent)
    }

    private val launcherIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == CAMERA_X_RESULT) {
            val myFile = it.data?.getSerializableExtra("picture") as File
            val isBackCamera = it.data?.getBooleanExtra("isBackCamera", true) as Boolean

            val result = rotateBitmap(
                BitmapFactory.decodeFile(myFile.path),
                isBackCamera
            )
            bitmap = result

            binding.ivMain.setImageBitmap(result)
        }
    }

    private fun setupViewModel() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[MainViewModel::class.java]

        mainViewModel.getUser().observe(this) { user ->
            if (!user.stateOnBoarding) {
                startActivity(Intent(this, OnBoardingActivity::class.java))
                finish()
            }
            else if (!user.stateTutorial) {
                startActivity(Intent(this, TutorialActivity::class.java))
                finish()
            }
            else {
                if (!allPermissionsGranted()) {
                    ActivityCompat.requestPermissions(
                        this,
                        REQUIRED_PERMISSIONS,
                        REQUEST_CODE_PERMISSIONS
                    )
                }
            }
        }
    }

//    private fun startTakePhoto() {
//        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//        intent.resolveActivity(packageManager)
//        createCustomTempFile(application).also {
//            val photoURI: Uri = FileProvider.getUriForFile(
//                this,
//                "com.example.imageclassification",
//                it
//            )
//            currentPhotoPath = it.absolutePath
//            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
//            if (currentPhotoPath.isEmpty()) {
//                currentPhotoPath = it.absolutePath
//            } else {
//                launcherIntentCamera.launch(intent)
//            }
//        }
//    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, getString(R.string.select_image))
        launcherIntentGallery.launch(chooser)
    }

//    private lateinit var currentPhotoPath: String
    private var getFile: File? = null
//    private val launcherIntentCamera =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
//            if (res.resultCode == RESULT_OK) {
//                val myFile = File(currentPhotoPath)
////                val result = rotateBitmap(BitmapFactory.decodeFile(myFile.path), currentPhotoPath)
////                val bitmap = BitmapFactory.decodeFile(result.path)
////                getFile = result
////                binding.imageView.setImageBitmap(bitmap)
//                getFile = reduceRotateFileImage(myFile)
//                val result = BitmapFactory.decodeFile(myFile.path)
//                bitmap=result
//                binding.ivMain.setImageBitmap(result)
//            }
//        }

    private val launcherIntentGallery =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                val selectedImg: Uri = it.data?.data as Uri
                val myFile = uriToFile(selectedImg, this)
                val result = BitmapFactory.decodeFile(myFile.path)
                bitmap=result
                getFile = myFile
                binding.ivMain.setImageURI(selectedImg)
            }
        }

    var handler: Handler = Handler()
    var runnable: Runnable? = null
    var delay = 500
//    @RequiresApi(Build.VERSION_CODES.M)
    override fun onStart() {
        super.onStart()
        handler.postDelayed(Runnable {
            handler.postDelayed(runnable!!, delay.toLong())
            checkButtonAvailability()
        }.also { runnable = it }, delay.toLong())
    }

//    @RequiresApi(Build.VERSION_CODES.M)
    private fun checkButtonAvailability() {
        if (bitmap != null) {
            Log.d("ceklah", bitmap.toString())
            binding.buttonPrediction.isEnabled = true
            binding.buttonClearImage.isEnabled = true
            binding.buttonClearImage.setImageResource(R.drawable.ic_baseline_close_24)
//            binding.buttonClearImage.setBackgroundColor(R.color.purple_500)
        } else{
            Log.d("ceklah", bitmap.toString())
            binding.buttonPrediction.isEnabled = false
            binding.buttonClearImage.isEnabled = false
            binding.buttonClearImage.setImageResource(0)
        }
    }


    private lateinit var bottomDrawerBehavior: BottomSheetBehavior<View>
    override fun onBackPressed() {
        if (bottomDrawerBehavior.state != BottomSheetBehavior.STATE_HIDDEN) {
            bottomDrawerBehavior.state = BottomSheetBehavior.STATE_HIDDEN
            return
        }
        super.onBackPressed()
    }

    private fun setUpBottomDrawer() {
        bottomDrawerBehavior = BottomSheetBehavior.from(binding.bottomDrawer)
        bottomDrawerBehavior.state = BottomSheetBehavior.STATE_HIDDEN

        binding.bar.setNavigationOnClickListener {
            bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HALF_EXPANDED)
        }
        binding.bar.setNavigationIcon(R.drawable.ic_drawer_menu_24px)
//        binding.bar.replaceMenu(R.menu.option_menu)
        binding.bar.setOnMenuItemClickListener(this)

        binding.navigationView.setNavigationItemSelectedListener { item ->
            bottomDrawerBehavior.state = BottomSheetBehavior.STATE_HIDDEN
            onMenuItemClick(item)
        }

        binding.coordinatorLayout.setOnClickListener{
            bottomDrawerBehavior.state = BottomSheetBehavior.STATE_HIDDEN
        }
    }

    override fun onMenuItemClick(item: MenuItem) = when (item.itemId) {
        R.id.menu1 -> {
            startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
            true
        }
        R.id.menu2 -> {
            launchShareIntent()
            true
        }
        else -> false
    }

//    override fun onCreateOptionsMenu(menu: Menu): Boolean {
//        menuInflater.inflate(R.menu.option_menu, menu)
//        return super.onCreateOptionsMenu(menu)
//    }
//
//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        return when (item.itemId) {
//
//            R.id.menu1 -> {
//                startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
//                true
//            }
//
//            else -> true
//        }
//    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//
//        if(requestCode == 250){
//            binding.ivMain.setImageURI(data?.data)
//
//            var uri : Uri ?= data?.data
//            bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, uri)
//        }
//        else if(requestCode == 200 && resultCode == Activity.RESULT_OK){
//            bitmap = data?.extras?.get("data") as Bitmap
//            binding.ivMain.setImageBitmap(bitmap)
//        }
//    }

    fun getMax(arr:FloatArray) : Int{
        var ind = 0;
        var min = 0.0f;

        for(i in 0..1000)
        {
            if(arr[i] > min)
            {
                min = arr[i]
                ind = i;
            }
        }
        return ind
    }

    companion object {
        const val CAMERA_X_RESULT = 200
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }
}