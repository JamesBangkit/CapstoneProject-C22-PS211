package com.example.imageclassification

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.imageclassification.databinding.ActivityTutorialBinding
import com.example.imageclassification.model.UserModel
import com.example.imageclassification.model.UserPreference
import com.example.imageclassification.viewmodel.MainViewModel
import com.example.imageclassification.viewmodel.TutorialViewModel

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class TutorialActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTutorialBinding
    private lateinit var tutorialViewModel: TutorialViewModel
    private lateinit var user: UserModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTutorialBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        setupViewModel()

        binding.button.setOnClickListener(){
            tutorialViewModel.getUser().observe(this) { user ->
                this.user = user
                tutorialViewModel.saveUser(UserModel(true, true))
            }
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun setupViewModel() {
        tutorialViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[TutorialViewModel::class.java]

        tutorialViewModel.getUser().observe(this) { user ->
            this.user = user
        }
    }
}