package com.example.imageclassification.model

data class UserModel (
    val stateOnBoarding: Boolean,
    val stateTutorial: Boolean
)

data class DetailModel (
    val acneType: String,
    val acneDescription: String,
    val acneRecommendation: String
)