package com.example.imageclassification.model

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class UserPreference private constructor(private val dataStore: DataStore<Preferences>) {
    fun getUser(): Flow<UserModel> {
        return dataStore.data.map { preferences ->
            UserModel(
                preferences[ONBOARDING_KEY] ?: false,
                preferences[TUTORIAL_KEY] ?: false
            )
        }
    }

    suspend fun saveUser(user: UserModel) {
        dataStore.edit { preferences ->
            preferences[ONBOARDING_KEY] = user.stateOnBoarding
            preferences[TUTORIAL_KEY] = user.stateTutorial
        }
    }

    companion object{
        @Volatile
        private var INSTANCE: UserPreference? = null

        private val ONBOARDING_KEY = booleanPreferencesKey("stateOnBoarding")
        private val TUTORIAL_KEY = booleanPreferencesKey("stateTutorial")
        private val TYPE_KEY = stringPreferencesKey("acneType")
        private val DESCTIPTION_KEY = stringPreferencesKey("acneDescription")
        private val RECOMMENDATION_KEY = stringPreferencesKey("acneRecommendation")

        fun getInstance(dataStore: DataStore<Preferences>): UserPreference {
            return INSTANCE ?: synchronized(this) {
                val instance = UserPreference(dataStore)
                INSTANCE = instance
                instance
            }
        }
    }
}